<div class="px-12 py-4 bg-slate-50">
    <h2 class="text-4xl font-extrabold dark:text-white text-center mb-4">Öne Çıkan Etkinlikler</h2>
    <div class="flex flex-col lg:flex-row gap-10 lg:gap-6 justify-between">
        <?php $__currentLoopData = $featuredEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('components.partials.featured-event-card', [
                'image' => $event->image,
                'eventTitle' => $event->title,
                'date' => $event->date,
                'location' => $event->location,
                'platform' => $event->site,
                'eventLink' => $event->url
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php /**PATH /Users/aliozgur/Desktop/git/event-tracker/resources/views/components/featured-events.blade.php ENDPATH**/ ?>