<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('event-list')->html();
} elseif ($_instance->childHasBeenRendered('IFuupNl')) {
    $componentId = $_instance->getRenderedChildComponentId('IFuupNl');
    $componentTag = $_instance->getRenderedChildComponentTagName('IFuupNl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IFuupNl');
} else {
    $response = \Livewire\Livewire::mount('event-list');
    $html = $response->html();
    $_instance->logRenderedChild('IFuupNl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH /Users/aliozgur/Desktop/git/event-tracker/resources/views/components/horizontal-event-list.blade.php ENDPATH**/ ?>