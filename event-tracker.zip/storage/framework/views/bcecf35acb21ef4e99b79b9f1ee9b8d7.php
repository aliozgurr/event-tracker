<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
    <body>
        <main>
            <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </main>

        <?php echo \Livewire\Livewire::scripts(); ?>


        <script>
            function search(e) {
                console.log('test')
                let query = document.getElementById('simple-search').value;
                window.location.href = '/events?search=' + query;
            }

            document.getElementById('simple-search').addEventListener('keyup', function (e) {
                if (e.key === 'Enter') {
                    search(e);
                }
            });
        </script>

        <?php echo $__env->yieldPushContent('scripts'); ?>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script>
    </body>
</html>
<?php /**PATH /Users/aliozgur/Desktop/git/event-tracker/resources/views/layout.blade.php ENDPATH**/ ?>