<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.featured-events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="p-12 grid grid-cols-1 lg:grid-cols-6 gap-8">
        <div class="col-span-1 lg:col-span-4">
            <?php echo $__env->make('components.horizontal-event-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-span-1 lg:col-span-2">
            <?php echo $__env->make('components.upcoming-events-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.getElementById('show-more-cities').addEventListener('click', function (e) {
            e.preventDefault();
            Array.from(document.getElementsByClassName('city-button')).forEach(function (element) {
                element.classList.remove('hidden');
            });
            document.getElementById('show-more-cities').classList.add('hidden');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aliozgur/Desktop/git/event-tracker/resources/views/pages/home.blade.php ENDPATH**/ ?>