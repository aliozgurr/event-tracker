<?php $__env->startSection('content'); ?>
    <div class="p-12">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('event-index')->html();
} elseif ($_instance->childHasBeenRendered('aXsgLE6')) {
    $componentId = $_instance->getRenderedChildComponentId('aXsgLE6');
    $componentTag = $_instance->getRenderedChildComponentTagName('aXsgLE6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aXsgLE6');
} else {
    $response = \Livewire\Livewire::mount('event-index');
    $html = $response->html();
    $_instance->logRenderedChild('aXsgLE6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aliozgur/Desktop/git/event-tracker/resources/views/pages/index.blade.php ENDPATH**/ ?>