<?php return array (
  'event-index' => 'App\\Http\\Livewire\\EventIndex',
  'event-list' => 'App\\Http\\Livewire\\EventList',
);