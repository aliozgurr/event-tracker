@extends('layout')

@section('content')
    <div class="p-12">
        @livewire('event-index')
    </div>
@endsection
