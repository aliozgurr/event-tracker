<div>
    @livewire('event-list')
</div>
